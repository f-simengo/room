</main>
  
  <footer class="page-footer font-small " style="background-color:#0e5a6e; color:white; margin:0px;padding-top:1px ">
              <div class="container text-center text-md mt-5 ">
                  <div class="row">
                       <!-- ...............divers................. -->
                      <div class="col-md-3 col-lg-4 col-xl-2 mx-auto mb-4">
  
  
                      <h6 style="font-weight-bold">DIVERS</h6>
                          <hr class=" text-light accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
                          <p>
                              <a href="mentions.php">Mentions legales</a>
                          </p>
                          <p>
                              <a href="cgv.php">Conditions Générales de Vente</a>
                          </p>
                        
                      </div>
  <!-- ...............partage................. -->
                      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
  
  
                      <h6 style="font-weight-bold">PARTAGE</h6>
                          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
                         
                          <iframe
                              src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=small&width=105&height=20&appId"
                              width="105" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0"
                              allowTransparency="true" allow="encrypted-media"></iframe>
                          <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" class="twitter-share-button"
                              data-show-count="false">Tweet</a>
                          <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                      </div>
  
    <!-- ...............contact................. -->
                      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                          
  
                    <h6 style="font-weight-bold"> <a href="<?= URL . 'contact.php' ?>">CONTACT</a></h6> 
                    
                       
                          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
                          <p>
                              <i class="fas fa-home mr-3"></i> 300 boulevard de Sébastopol, Paris 75003, France</p>
                          <p>
                              <i class="fas fa-envelope mr-3"></i> room@luxe.com</p>
                          <p>
                              <i class="fas fa-phone mr-3"></i> + 01 45 56 67 88</p>
                          <p>
                              <i class="fas fa-print mr-3"></i> + 01 45 56 67 89</p>
                          <br>
                       
                      </div>
                  </div>
              </div>
  
              <hr>
              <!-- Copyright -->
              <div class="footer-copyright text-center py-3"> &copy; <?= date('Y') ?> - 
                  <span id="createurs">Atayi & Simengo</span> - Tous droits réservés
              </div>
          </footer>   

  

</body>
</html>