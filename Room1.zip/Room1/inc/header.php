<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ROOM | <?= $title ?></title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= URL . 'inc/css/style.css' ?>">

    <script src="https://code.jquery.com/jquery-3.4.0.min.js"
   ></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="inc/css/jquery-ui.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"> </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
    <script src="<?= URL . 'inc/js/functions.js' ?>"></script>
    <link href="https://fonts.googleapis.com/css?family=Kanit&display=swap" rel="stylesheet">
</head>
<body>

    <header>
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
            <a class="navbar-brand" href="<?= URL ?>">ROOM</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">

                <li class="nav-item <?= ( $title == 'Accueil') ? 'active': '' ?>">
                    <a class="nav-link " href="<?= URL ?>">Accueil<span class="sr-only">(current)</span></a>
                </li>
                <?php
                    if( isConnected() ) :
                ?>
                   
                  
                 
                   <li class="nav-item <?= ( $title == 'Mon profil') ? 'active': '' ?>">
                    <a class="nav-link" href="<?= URL . 'profil.php?pseudo='.$_SESSION['pseudo'] ?>"><i class="fas fa-user"></i> Mon profil</a>
                    </li>
                <?php
                    else:
                        ?>
                         <li class="nav-item dropdown">               
                            <a class="nav-link dropdown-toggle" href="#" id="menumembre" role="button" data-toggle="dropdown"><i class="fas fa-user"></i> Espace membres</a>
                            <div class="dropdown-menu" aria-labelledby="menumembre">
                   
                            <a class="dropdown-item"  href="<?= URL . 'inscription.php' ?>">Inscription</a>
                  
                   
                            <a class="dropdown-item"  href="<?= URL . 'connexion.php' ?>">Connexion</a>
                   
                        </li>
                        <?php
                    endif;

                    if (isAdmin()):
                        ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="menuadmin" role="button" data-toggle="dropdown"><i class="fa fa-tools"></i> Admin</a>
                            <div class="dropdown-menu" aria-labelledby="menuadmin">

                                <a class="dropdown-item" 
                                href="<?= URL . 'admin/gestion_produits.php' ?>">Gestion des produits</a>
                                <a class="dropdown-item" 
                                href="<?= URL . 'admin/gestion_salles.php' ?>">Gestion des salles</a>
                                <a class="dropdown-item" 
                                href="<?= URL . 'admin/gestion_membres.php' ?>">Gestion des membres</a>
                                <a class="dropdown-item" 
                                href="<?= URL . 'admin/gestion_avis.php' ?>">Gestion des avis</a>
                                <a class="dropdown-item" 
                                href="<?= URL . 'admin/gestion_commandes.php' ?>">Gestion des commandes</a>
                                <a class="dropdown-item" 
                                href="<?= URL . 'admin/statistiques.php' ?>">Statistiques</a>
                            </div>
                        </li>
                        <?php
                    endif;

                    if( isConnected() ) :
                ?>
                    <li class="nav-item <?= ( $title == 'Connexion') ? 'active': '' ?>">
                        <a class="nav-link" href="<?= URL . 'connexion.php?action=deconnexion' ?>">Déconnecter</a>
                    </li>
                <?php
                    endif;
                ?>
                </ul>
                <form method="post" action="<?= URL . 'recherche.php'?>" class="form-inline mt-2 mt-md-0">
                <span class="text-light mx-2">
                    <?= $_SESSION['membre']['pseudo'] ?? '' ?>
                </span>
                <input class="form-control mr-sm-2" type="text" placeholder="produit à Rechercher" aria-label="Search"  name="critere" id="critere">
                <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Rechercher</button>
                </form>
            </div>
        </nav>
    </header>
    <main class="container">