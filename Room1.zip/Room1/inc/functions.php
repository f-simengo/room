<?php

// Identifier un membre connecté
function isConnected(){
    if( isset($_SESSION['membre']) ){
        return true;
    }
    else{
        return false;
    }
}
// Identifier un admin
function isAdmin(){
    if( isConnected() && $_SESSION['membre']['statut'] == 1){
        return true;
    }
    else{
        return false;
    }
}

// Fonction qui execute une requête (nettoyage inclus)
function execRequete($req,$params=array()){

    // Assainissement
    if( !empty($params) ){
        foreach($params as $key => $value){
            $params[$key] = htmlspecialchars($value,ENT_QUOTES);
        }
    }

    // globalisation de $pdo
    global $pdo;

    $r = $pdo->prepare($req);
    $r->execute($params);
    return $r;
}

