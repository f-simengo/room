
$(document).ready(function(){

    $('#photo').change(function(e){

        $('#nomfichier').html(e.target.files[0].name);

        // si je souhaite prévisualiser la photo à l'ajout d'un prod
        var reader = new FileReader();
        reader.onload = function(e){
            $('#box').html('<img src="'+e.target.result + '" class="img-fluid">');
        }
        reader.readAsDataURL(e.target.files[0]);
    });

    $('.confsup').on('click',function(){
        return(confirm('Etes vous certain(e) de vouloir supprimer ce produit ?'));
    });

if($('#maModale').length == 1){
        $('#maModale').modal('show');
}
$('#critere').on('input',function(){
    if($.trim($('#critere').val()).length > 0){
        $(this).next('button[type=submit]').prop("disabled",false);

    }else{
        $(this).next('button[type=submit]').prop("disabled",true);

    }
    
})

if($('.cookies').length == 1){
    $('.cookies').animate({bottom: 0},1500);
    $('#accept').on('click', function(){
        $('.cookies').animate({bottom: '-90px'},1500);
        d= new Date();
        d.setTime(d.getTime() + 180 * 24 *60 *60 * 1000);
        document.cookie = "acceptCookies=true;expires=" + d.toGMTString();

    });
}

}); // Fin du Document Ready

