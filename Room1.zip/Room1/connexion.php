<?php

require_once('include/init.php');
$title = 'Connexion'; // titre de la page



require_once('include/header.php');




?>


<div class="container">

<h3>Veuillez renseigner vos identifiants</h3>
  <form action="" method="post">
    <div class="form-row">
        <div class="form-group col-12">
            <label for="pseudo">Pseudo</label>
            <input type="text" id="pseudo" name="pseudo" value="<?= $_POST['pseudo'] ?? '' ?>" class="form-control">
        </div>
        <div class="form-group col-12">
            <label for="mdp">Mot de passe</label>
            <input type="password" id="mdp" name="mdp" value="" class="form-control">
        </div>
    </div>
    <input type="submit" class="btn btn-info" value="Se connecter">
</form></div>

<?php
require_once('include/footer.php'); 
?>