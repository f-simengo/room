<?php
require_once('inc/init.php');
if(empty(trim($_POST['critere']))){
    header('location:'.URL);
    exit();
}
$title='Recherche de'.$_POST['critere'];
require_once('inc/header.php');
?>
<h1>Recherche de <?=$_POST['critere'] ?></h1>
<?php
$resultat = execRequete("SELECT * FROM produit WHERE 
titre LIKE CONCAT('%',:critere,'%')
OR couleur LIKE CONCAT('%',:critere,'%')
OR categorie LIKE CONCAT('%',:critere,'%')
OR description LIKE CONCAT('%',:critere,'%')
OR reference LIKE CONCAT('%',:critere,'%')", array('critere'=>trim($_POST['critere'])));

if($resultat->rowCount()>0){
    ?>
    <h2 class="text-secondary">Il y a <?=$resultat->rowCount()?> résultat(s) correspondant à votre recherche</h2>
    <div class="row">
      <?php
        while( $produit = $resultat->fetch() ){
          ?>
          <div class="col-12 col-sm-6 col-md-4 p-1">
              <div class="border">
                  <div class="thumbnail">
                      <a href="<?= URL . 'fiche_produit.php?id_produit=' . $produit['id_produit']?>">
                      <img src="<?= URL . 'photo/' . $produit['photo'] ?>" alt="<?= $produit['titre'] ?>" class="img-fluid">
                      </a>
                  </div>
                  <div class="caption mx-2">
                      <h4 class="float-right"><?= $produit['prix'] ?>€</h4>
                      <h4><a href="<?= URL . 'fiche_produit.php?id_produit=' . $produit['id_produit']?>"><?= $produit['titre'] ?></a></h4>
                  </div>
              </div>
          </div>
          <?php
      }

      ?>
      
    </div>
    <?php
}else{
    ?>
    <div class="alert alert-info">Nous n'avons pas trouvé de produit correcpondant à votre recherche</div>
    <?php
}

require_once('inc/footer.php');
