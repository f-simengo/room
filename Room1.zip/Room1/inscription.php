<?php

require_once('include/init.php');
$title = 'Inscription'; // titre de la page



require_once('include/header.php');



?>

<div class="container">
  <h3>Veuillez renseigner le formulaire pour vous inscrire</h3>
</div>
  <div class="container">
<form action="" method="post">
    <fieldset>
        <legend class="text-info">Identifiants</legend>
        <div class="form-row">
            <div class="form-group col-6">
                <label for="pseudo">Pseudo</label>
                <input type="text" id="pseudo" name="pseudo" class="form-control" value="<?= $_POST['pseudo'] ?? '' ?>">
            </div>
            <div class="form-group col-6">
                <label for="mdp">Mot de passe</label>
                <input type="password" id="mdp" name="mdp" class="form-control" value="">
            </div>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" class="form-control" value="<?= $_POST['email'] ?? '' ?>">
        </div>
    </fieldset>
    <fieldset>
        <legend class="text-info">Coordonnées</legend>
        <div class="form-row">
            <div class="form-group col-2">
                <label for="civilite">Civilité</label>
                <select id="civilite" name="civilite" class="form-control">
                    <option value="m">Monsieur</option>
                    <option value="f" <?= ( isset($_POST['civilite']) && $_POST['civilite']=='f' ) ? 'selected':'' ?>>Madame</option>
                </select>
            </div>
            <div class="form-group col-5">
                <label for="prenom">Prénom</label>
                <input type="text" id="prenom" name="prenom" class="form-control" value="<?= $_POST['prenom'] ?? '' ?>">
            </div>
            <div class="form-group col-5">
                <label for="nom">Nom</label>
                <input type="text" id="nom" name="nom" class="form-control" value="<?= $_POST['nom'] ?? '' ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="adresse">Adresse</label>
            <input type="text" id="adresse" name="adresse" class="form-control" value="<?= $_POST['adresse'] ?? '' ?>">
        </div>
        <div class="form-row">
            <div class="form-group col-3">
                <label for="code_postal">Code Postal</label>
                <input type="text" maxlength="5" id="code_postal" name="code_postal" class="form-control" value="<?= $_POST['code_postal'] ?? '' ?>">
            </div>
            <div class="form-group col-9">
                <label for="ville">Ville</label>
                <input type="text" id="ville" name="ville" class="form-control" value="<?= $_POST['ville'] ?? '' ?>">
            </div>
        </div>
    </fieldset>
    <input type="submit" class="btn btn-info" style="margin: 10px 0" value="S'inscrire">
</form></div>


<?php






require_once('include/footer.php');
?>