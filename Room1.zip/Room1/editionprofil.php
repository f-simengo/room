<?php

require_once('inc/init.php');
$title = 'Edition profil'; // titre de la page
if (isset($_SESSION['pseudo']))
{
    $requsere = $pdo -> prepare("SELECT * FROM membre WHERE pseudo = ?");
    $requsere -> execute(array($_SESSION['pseudo']));
    $user = $requsere-> fetch();

    
    if(isset($_POST['nouveau_pseudo']) AND !empty($_POST['nouveau_pseudo']) AND
    $_POST['nouveau_pseudo'] != $user['pseudo'])
    {   $nouveau_pseudo = trim(htmlspecialchars($_POST['nouveau_pseudo']));
        $insertpseudo = $pdo -> prepare("UPDATE membre SET pseudo = ? WHERE pseudo = ?");
        $insertpseudo -> execute(array($nouveau_pseudo, $_SESSION['pseudo']));
        header('Location: profil.php?pseudo='.$_SESSION['pseudo']);
        echo'Votre pseudo a été modifié avec succés';
      
    }


    if(isset($_POST['nouveau_email']) AND !empty($_POST['nouveau_email']) AND
    $_POST['nouveau_email'] != $user['email'])
    {   $nouveau_email = trim(htmlspecialchars($_POST['nouveau_email']));
        $insertemail = $pdo -> prepare("UPDATE membre SET email = ? WHERE pseudo = ?");
        $insertemail -> execute(array($nouveau_email, $_SESSION['pseudo']));
        header('Location: profil.php?pseudo='.$_SESSION['pseudo']);
 
    }
   

    
    if(isset($_POST['nouveau_mdp']) AND !empty($_POST['nouveau_mdp']) AND isset($_POST['confirm_mdp']) AND !empty($_POST['confirm_mdp']))

    {  
        $mdp1 = sha1($_POST['nouveau_mdp']);
        $mdp2 =  sha1($_POST['confirm_mdp']);
        if ($mdp1 != $mdp2){
            
            echo'Vos 2 mots de passe ne correspondent pas';
        }
        
        $insertmdp = $pdo -> prepare("UPDATE membre SET mdp = ? WHERE pseudo = ?");
        $insertmdp -> execute(array($mdp1, $_SESSION['pseudo']));
        header('Location: profil.php?pseudo='.$_SESSION['pseudo']);
        //echo'Votre mot de passe a été modifié avec succés';
    }
   
   
require_once('inc/header.php');
?>
<h3>Edition de mon profil:</h3>
<form method="post" action="">
    <label> Pseudo: </label>
						<input type="text" name="nouveau_pseudo" placeholder="Nouveau pseudo..."value="<?php echo $user ['pseudo'];?>" required> <br> <br>
                        <label> Email: </label>
						<input type="email" name="nouveau_email" placeholder="Nouveau email..."value="<?php echo $user ['email'];?>" required> <br> <br>
                        <label> Mot de passe: </label>
						<input type="password" name="nouveau_mdp" placeholder="Votre nouveau mot de passe..." required> <br> <br>
                        <input type="password" name="confirm_mdp" placeholder="Confirmer nouveau passe..." required>
						<input type="submit" name="valider" value="Valider la modification">
					</form>


<?php
}

require_once('inc/footer.php'); 


?>