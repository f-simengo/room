<?php

require_once('inc/init.php');
$title = 'fiche Produit'; //titre de la page






if( !empty($_GET['id_produit'])){

    $resultat = execRequete("SELECT * FROM salle s, produit p WHERE s.id_salle = p.id_salle AND p.id_produit=:id_produit",array('id_produit' => $_GET['id_produit']));
    if($resultat->rowCount() == 1){
        $produit = $resultat->fetch();
        $produit_id = $produit['id_salle'];
    }else{
        // header('location:' . URL);
        // exit();
    }

}
$id_salle = $_GET['id_produit'];

require_once('inc/header.php');

?>


<div class="container"style="border: 1px solid grey; ">
 
    <div class="row">

    
      <div class="col-10">  <h1 class="page-header text-center"><?= $produit['titre'] ?> </div>
      <div class="col-2">
      <?php
if( isConnected() ) :
?>
<form action=""method="post"> <input type="submit" name="reserver" value="Reservez" class="btn btn-info"style="margin:10px;"onclick="return(confirm('etes-vous sur'));"></div></form>

<?php
else:
    ?>
 <a  class="btn btn-info" href="<?= URL . 'connexion.php' ?>">Connexion</a>
  
    <?php
endif;        

if( isset($_POST['reserver']) ) :

echo'Votre salle a été bien réservée';
   
else:
    echo'Votre salle est disponible';
endif;        
?>
</div>
</div>
<div class="container"style="border: 1px solid grey;">
<div class="row">
 
    <div class="row align-items-center mt-2">
      <div class="col-lg-7">
        
      <img src="<?= URL . 'photo/' . $produit['photo'] ?>" alt="<?= $produit['titre'] ?>" class="img-fluid">
      </div> 
     <div class="col-lg-5">

     <h2>Description:</h2>
		<p><?php echo $produit['description']?></p>
      </div>
      
    </div> 
    </div> 
    </div>
    
    <div class="container"style="padding: 0;">
 
 <div class="row">
   <div class="col-12">
    
    <div class="card text-white bg-secondary my-5 py-4 text-center"style="padding: 0;">
      <div class="card-body">
           <h3>Informations complementaires</h3>
               
             
                    <p>Catégorie : <?= $produit['categorie'] ?></p>
                    <p>Capacité : <?= $produit['capacite'] ?></p>
                    <p>Adresse : <?= $produit['adresse'] ?></p>
                    <p> Code postal: <?= $produit['cp'] ?></p>
                    <p> Ville: <?= $produit['ville'] ?></p>
                    <p> Du: <?= $produit['date_arrivee'] ?></p>
                    <p> Au: <?= $produit['date_depart'] ?></p>
               
                <p class="lead">Prix : <?= $produit['prix'] ?> €</p>
      </div>
    </div>
    </div>
    </div>

 

 <?php

if(isset($_POST['reserver'])){
    if (isset($_GET['id_produit'])) {
                        execRequete("INSERT INTO commande (id_membre, id_produit, date_enregistrement) VALUES (:id_membre, :id_produit, NOW())", array('id_produit' => $_GET['id_produit'], 'id_membre' => $_SESSION['membre']['id_membre']));
    
                        execRequete("UPDATE produit SET etat = 'reservation' WHERE id_produit=:id_produit ", array('id_produit' => $_GET['id_produit']));
    
                      
       
                    }
                    ?>
                </div>
            </div>
          
    
            <?php
       
    
    }
 if(!isset($_GET['id_produit'])){
   
 }
 

 if(isset($_POST['id_salle']) && isset($_POST['commentaire']) && isset($_POST['note'])){
    $nb_champs_vides = 0;
    foreach($_POST as $value){
        if( trim($value) == ''){
            $nb_champs_vides++;
        }
    }
    if( $nb_champs_vides > 0){
        $content .= '<div class="alert alert-danger">Merci de remplir les '.$nb_champs_vides.' champ(s) manquant(s)</div>';
    }
    if(empty($content)){
        execRequete("INSERT INTO avis VALUE (NULL,:id_membre,:id_salle,:commentaire,:note,now())",array(
            'id_membre'=>$_SESSION['membre']['id_membre'],
            'id_salle'=>$_POST['id_salle'],
            'commentaire'=>$_POST['commentaire'],
            'note'=>$_POST['note']

        ));

    }

 }

$id_salle = $_GET['id_produit'];
$avis = execRequete("SELECT *, DATE_FORMAT(a.date_enregistrement, '%d/%m/%Y') AS date_enregistrement_fr FROM produit p INNER JOIN avis a INNER JOIN membre m ON p.id_produit = id_produit AND a.id_membre = m.id_membre WHERE p.id_produit = $id_salle");
// $produit = $avis->fetch();


require_once('inc/header.php');
echo $content
?>

<div class="container"style="padding: 0;">
<div class="row">
    
<div class="col text-center ">
<div class="col-sm-12 text-center table-responsive-sm">

<h2>Commentaires de la salle:</h2>
<?php
if( isConnected() ) :
?>
<h5>" <?=$_SESSION['membre']['pseudo']?>, pensez à laisser un commentaire ! "</h5>
<?php
else:
    ?>
 
  
    <?php
endif;


while($produit=$avis->fetch()){
   
     
    ?>
    
    <table class="table table-bordered"><thead class="thead-blue"><tr>
            <th><?=$produit['pseudo']?></th>
            <th><?=$produit['commentaire']?></th>
            <th><?=$produit['note'] . '/5'?></th>
            <th><?=$produit['date_enregistrement_fr']?></th>
      
            
        </tr></thead></table>


        <?php
        }
?>
        <hr></div></div>

    
  
        </div>
      

        <div class="row">
        <div class="col text-center ">




    <?php
    if( isConnected() ) :
?>
<form method="POST" class="form-group">

<label for="commentaire">Commentaire</label>
<textarea name="commentaire" placeholder="Votre commentaire..." class="form-control"></textarea><br />

<input type="hidden" name="id_salle" value="<?php echo $produit_id; ?>">

<div class="row">
     <div class="col-2 text-center ">
<label for="note">Note</label>
<select id="note" name="note" class="form-control" value="">
                
                 <option value="1">1</option>
                 <option value="2">2</option>
                 <option value="3">3</option>
                 <option value="4">4</option>
                 <option value="5">5</option>
                
             </select>
             </div>
             </div>
             
      
        <br> <b></b>  
 <input type="submit" value="Poster mon commentaire" name="submit_commentaire" class="btn btn-info"/>
 
<?php
else:
    ?>
 <p>Vous voulez laisser un commentaire ! Alors <a href="<?= URL . 'connexion.php' ?>"> connectez-vous</a></p>
  
    <?php
  
   
endif;

?>
  
</form>

</div> 
</div>
</div>
</div>
<?php
require_once('inc/footer.php');