<?php

require_once('inc/init.php');
$title = ''; //titre de la page

require_once('inc/header.php');
?>

<div class="container-fluid" style="padding:0 ;margin:100px 0 100px 0;background-color:rgb(255, 255, 255)">



<div class="container"style="padding:25px ;margin:auto;border-radius:10px;border:2px solid grey">
<div class="row">
    <div class="col md-12 text-center">
          
        <h2>CONDITIONS GENERALES DE VENTES</h2>
        <h4 id="sous-titre" style="padding:20px">location de salles</h4>
        <P style="text-align:center">
            <strong> SERVICES DE LOCATION</strong> <br>
            <p style="text-align:justify">Chaque service en ligne limite la collecte des données personnelles au strict nécessaire (minimisation des données) et s’accompagne d’une information sur : • le responsable du traitement et les objectifs du recueil de ces données
                (finalités) ; • la base juridique du traitement de données ; • le caractère obligatoire ou facultatif du recueil des données pour la gestion de votre demande et le rappel des catégories de données traitées ; • la source des
                données (lorsque d’autres données que celles fournies via le service en ligne sont utilisées pour le traitement de votre demande) ; • les catégories de personnes concernées ; • les destinataires des données (uniquement la CNIL
                en principe, sauf précision lorsqu'une transmission à un tiers est nécessaire) ; • la durée de conservation des données ; • les mesures de sécurité (description générale) ; • l’existence éventuelle de transferts de données
                hors de l’Union européenne ou de prises de décision automatisées ; • vos droits Informatique et Libertés et la façon de les exercer auprès de la CNIL. Les données personnelles recueillies dans le cadre des services proposés
                sur cnil.fr sont traitées selon des protocoles sécurisés et permettent à la CNIL de gérer les demandes reçues dans ses applications informatiques.
            </p>


            <p style="text-align:center"> <strong>	PARCOURS DE RÉSERVATION</strong> <br> Pour toute information ou exercice de vos droits Informatique et Libertés sur les traitements de données personnelles gérés par la CNIL, vous pouvez contacter son délégué à la protection des données
                (DPO) : • par ce formulaire • ou par courrier (avec copie de votre pièce d’identité en cas d'exercice de vos droits) à l'adresse suivante : Commission Nationale de l'Informatique et des Libertés A l'attention du délégué à la
                protection des données (DPO) 3 Place de Fontenoy TSA 80715 75334 PARIS CEDEX 07
            </p>
            <p style="text-align:center"> <strong> PRIX ET PAIEMENT </strong> <br> Les prix afférents à la réservation des Services sont indiqués avant, pendant et après la réservation.

                Pour les Services d’Hébergement, les prix indiqués s’entendent par chambre pour le nombre de personne(s) et la date sélectionnée
                
                Lors de la confirmation de la réservation d’un Service, le prix total est indiqué au Client en montant TTC dans la devise commerciale de l’Etablissement (qui dans certains cas peut être différente de la monnaie locale de l’Etablissement) et n’est valable que pour la durée indiquée sur le Site.
                
                Si le débit du prix total de la réservation du Service s’effectue à l’Etablissement dans une monnaie autre que celle confirmée sur la réservation, les frais de change sont à la charge du Client. A noter que si une conversion de la monnaie confirmée sur la réservation en une
                 autre monnaie apparait
                 sur le Site, elle est donnée à titre purement indicatif et non contractuel, compte tenu notamment de la possible évolution des taux de change entre la date de réservation et les dates de séjour à l’Etablissement.
                
                Sauf mention contraire sur le Site, les options (par exemple, petit déjeuner, demi-pension, pension complète etc.) qui ne sont pas proposées au moment de la réservation du Service ne sont incluses dans le prix.
                
                La taxe de séjour, présentée lors du parcours de réservation du Service, est à régler directement sur place auprès de l’Etablissement, sauf dans le cas d’un prépaiement en ligne avant le séjour où ce montant peut être inclus
                
                Les prix tiennent compte de la TVA applicable au jour de la réservation et tout changement du taux applicable à la TVA sera automatiquement répercuté sur le prix indiqué à la date de facturation.
                
                Toute modification ou instauration de nouvelles taxes légales ou réglementaires imposées par les autorités compétentes seront automatiquement répercutées sur le prix indiqué à la date de la facturation.
                
                Enfin, certaines offres promotionnelles sont uniquement disponibles sur le Site sont vendues exclusivement sur internet et en aucun cas à la réception de l’Etablissement.
                
            
                Le Client communique ses données de paiement soit (i) pour prépayer la réservation avant le séjour, (ii) soit au titre de garantie de la réservation, (iii) soit au titre de la procédure de check-out en ligne proposée dans le cadre du Service Welcome telle 
                que décrit au paragraphe 4.3 ci-dessous, en indiquant directement, dans la zone prévue à cet effet (saisie sécurisée par cryptage SSL) lorsqu’il s’agit d’une carte bancaire, le numéro de carte bancaire, sans espaces entre les chiffres, ainsi que sa date de validité
                 (il est précisé que la carte bancaire utilisée doit être 
                valable au moment du séjour) et le cryptogramme visuel dans le cadre d’un prépaiement via les plateformes de paiement ci-après mentionnées.</p>
        </p>
        <strong style="text-align:justify">  SERVICE WELCOME (CHECK-IN ET CHECK-OUT EN LIGNE)</strong> 
        <p style="text-align:justify">Le Client recevra une réponse de l’Etablissement quant à la possibilité de bénéficier de ce service dans les 2 jours suivant sa demande.

                Dans certains cas, le check-in en ligne ne peut être réalisé que si le check-out est également effectué en ligne. Dans cette hypothèse, le Client demeure libre de refuser le check-out en ligne (aussi appelé « fast check-out »), ce qui annulera la demande de check-in réalisée en ligne ainsi que plus globalement le Service Welcome.
                
                Dans les cas où le check-out en ligne n’est pas obligatoire, le Client peut réaliser le check-in en ligne et le check-out à l’Etablissement.
                
                Le check-out en ligne se traduit par une demande d'autorisation (appelée également « préautorisation ») auprès de la banque du Client. Cette procédure consiste en une garantie valable pour un montant estimé du séjour et donne une autorisation de paiement à l’Etablissement sur la base des dépenses réelles du Client à concurrence du montant
                 autorisé. Seul le montant réel de la facture sera débité par l’Etablissement à partir du départ du Client à la fin de son séjour, sans nécessiter la présence physique du Client ni une nouvelle validation de sa part.
                
                Le montant de la demande d'autorisation comprend le montant de la réservation (ou le montant restant à payer en cas de prépaiement partiel au moment de la réservation) et un montant forfaitaire permettant de couvrir d'éventuelles consommations ou dépenses du Client sur place (petit déjeuner s'il n'est pas inclus dans le tarif, restaurant,
                 bar, taxe de séjour le cas échéant, etc.). Ce montant forfaitaire est déterminé par l'Etablissement en fonction du nombre de personnes et du nombre de nuitées réservées. Exemple : 2 nuits à 130 euros + 40 euros estimés pour les extras = demande d'autorisation de 300 euros.
                
                La demande d'autorisation n’est pas un débit immédiat mais correspond à une réserve pour paiement ultérieur, autorisée par la banque du Client, qui vient temporairement réduire le plafond de la carte bancaire utilisée pour garantir la possibilité du débit ultérieur. Dans certains cas, la demande d'autorisation peut toutefois apparaître
                 comme un débit en attente sur le compte bancaire associé à la carte utilisée.
                
                Lorsque la demande d'autorisation a été activée et confirmée par la banque, à la fin du séjour, l'Etablissement transmet à la banque du Client une demande de débit correspondant au montant de la facture :
                •	si la Facture est inférieure au montant de la demande d'autorisation, le débit réel de la carte sera égal au montant réellement dû par le Client. Le plafond de la carte sera alors réajusté (libéré) par la banque du Client compte tenu de cette différence (avec un délai variable suivant les banques) ;
                Exemple : Demande d'autorisation de 300 euros, facture finale de 260 euros = débit de 260 euros et annulation de la demande d'autorisation pour les 40 euros restants.
                •	si la facture est supérieure au montant de la demande d'autorisation, celle-ci sera utilisée dans sa totalité par l’Etablissement. Le reliquat des dépenses sera débité en complément sur la même carte. Deux débits sont donc effectués sur le compte du Client. L'un correspond au montant de la demande d'autorisation et l'autre au complément.
                 Il est néanmoins conseillé au Client de repasser à la réception pour régulariser le montant de la demande d'autorisation ou payer directement. Exemple : Demande d'autorisation de 300 euros, Facture finale de 320 euros = débit de 300 euros + débit de 20 euros.
                
                Dans certains Etablissements, la monnaie utilisée par l’Etablissement pour la facture peut être différente de celle utilisée pour la demande d’autorisation. Dans ce cas, le montant réellement débité peut également différer du montant de la demande d’autorisation compte tenu de la possible évolution des taux de change entre la date de la demande 
                d’autorisation et la date de la facture
                
                Dans de rares cas, la demande d'autorisation peut se traduire par un débit par la banque du Client avant même que le débit réel ne soit effectif. Dans ce cas, le débit ne se fera pas deux fois. Le solde, s’il est en faveur du client, sera re-crédité automatiquement par la banque au Client.
                
                Si le Client, sur proposition de l’Etablissement, a souhaité prépayer l’ensemble de son séjour à son arrivée, les éventuelles dépenses additionnelles au sein de l’Etablissement ne pourront être rajoutées sur le compte de la chambre et seront à payer directement au moment des consommations.
                
                Si la réservation est annulée après que la demande d'autorisation a été activée, une demande d'annulation de la demande d'autorisation est automatiquement envoyée à la banque du porteur de la carte utilisée. Dans de rares cas, cette annulation pourra apparaître comme un remboursement.
                
                Il est à noter que la prise en compte de la libération du montant préautorisé (ou remboursement) prend habituellement vingt-quatre (24) à quarante-huit (48) heures mais le délai peut atteindre sept (7) jours ouvrables ou plus, en fonction de la banque du porteur.
        </p>



    </div>

</div>
</div>


</div>

<?php
require_once('inc/footer.php');
?>