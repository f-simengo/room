<?php
/*
silence is golden
*/