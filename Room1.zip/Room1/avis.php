<?php

require_once('inc/init.php');
$title = 'avis'; //titre de la page

if(!isset($_GET['id_produit'])){
   
 }
 

 if(!empty($_POST)){
    $nb_champs_vides = 0;
    foreach($_POST as $value){
        if( trim($value) == ''){
            $nb_champs_vides++;
        }
    }
    if( $nb_champs_vides > 0){
        $content .= '<div class="alert alert-danger">Merci de remplir les '.$nb_champs_vides.' champ(s) manquant(s)</div>';
    }
    if(empty($content)){
        execRequete("INSERT INTO avis VALUE (NULL,:id_membre,:id_salle,:commentaire,:note,now())",array(
            'id_membre'=>$_SESSION['membre']['id_membre'],
            'id_salle'=>$_GET['id_salle'],
            'commentaire'=>$_POST['commentaire'],
            'note'=>$_POST['note']

        ));

    }

 }

$id_salle = $_GET['id_produit'];
$avis = execRequete("SELECT *, DATE_FORMAT(a.date_enregistrement, '%d/%m/%Y') AS date_enregistrement_fr FROM produit p INNER JOIN avis a INNER JOIN membre m ON p.id_produit = id_produit AND a.id_membre = m.id_membre WHERE p.id_produit = $id_salle");
$produit = $avis->fetch();


require_once('inc/header.php');
echo $content
?>

<div class="container"style="padding: 0;">
<div class="row">
    
<div class="col text-center ">
<div class="col-sm-12 text-center table-responsive-sm">

<h2>Commentaires de la salle:</h2>
<?php
if( isConnected() ) :
?>
<h5>" <?=$_SESSION['membre']['pseudo']?>, pensez à laisser un commentaire ! "</h5>
<?php
else:
    ?>
 
  
    <?php
endif;


while($produit=$avis->fetch()){
   
     
    ?>
    
    <table class="table table-bordered"><thead class="thead-blue"><tr>
            <th><?=$produit['pseudo']?></th>
            <th><?=$produit['commentaire']?></th>
            <th><?=$produit['note'] . '/5'?></th>
            <th><?=$produit['date_enregistrement_fr']?></th>
      
            
        </tr></thead></table>


        <?php
        }
?>
        <hr></div></div>

    
  
        </div>
      

        <div class="row">
        <div class="col text-center ">




    <?php
    if( isConnected() ) :
?>
<form method="POST" class="form-group">

<label for="commentaire">Commentaire</label>
<textarea name="commentaire" placeholder="Votre commentaire..." class="form-control"></textarea><br />

<div class="row">
     <div class="col-2 text-center ">
<label for="note">Note</label>
<select id="note" name="note" class="form-control" value="">
                
                 <option value="1">1</option>
                 <option value="2">2</option>
                 <option value="3">3</option>
                 <option value="4">4</option>
                 <option value="5">5</option>
                
             </select>
             </div>
             </div>
             
      
        <br> <b></b>  
 <input type="submit" value="Poster mon commentaire" name="submit_commentaire" class="btn btn-infos"/>
 
<?php
else:
    ?>
 <p>Vous voulez laisser un commentaire ! Alors <a class=gg href="<?= URL . 'connexion.php' ?>"> connectez-vous</a></p>
  
    <?php
  
   
endif;

?>
  
</form>

</div> 
</div>
</div>
</div>

<?php
require_once('inc/footer.php');