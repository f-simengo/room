<?php

require_once('inc/init.php');
$title = 'Mentions'; // titre de la page


require_once('inc/header.php');
?>

<div class="container-fluid" style="padding:0px ;margin:100px 0 100px 0;background-color:rgb(255, 255, 255)">



<div class="container"style="padding:25px ;margin-right:auto; margin-left:auto; display:block;border-radius:10px;border:2px solid grey>
    <div class="row">
        
        <div class="col md-12 text-center">
            <h2>MENTIONS LEGALES</h2>
            <h4 id="sous-titre" style="padding:20px">Locations de salles</h4>
            </div>
            <P style="text-align:justify">
                <strong> MENTIONS LÉGALES MODALITÉS D'UTILISATION DU SITE WEB DE ROOM LIMITED - EN VIGUEUR
                    LE 24/06/15 IMPORTANT! CECI EST UN CONTRAT JURIDIQUE CONTRAIGNANT (le présent "Contrat").
                    VEUILLEZ LIRE CET ACCORD AVANT D'UTILISER CE SITE. DERNIÈRE MISE À JOUR 06/24/19.</strong> •
                <p style="text-align:justify">Le présent contrat régit votre utilisation de ce site Internet
                    situé à l' adresse wwRoom.com., y compris toutes les pages Web, les applications, le
                    «Contenu» (tel que défini ci-dessous), ainsi que les biens, services, caractéristiques
                    et fonctions fournis ou proposés sur ou via ce site (collectivement dénommés le «Site») et
                    se trouvant entre et entre Room Limited ( collectivement «Room», «nous», «notre»
                    ou «notre») et vous, que vous accédiez
                    au site par vous-même, par un intermédiaire ou pour le compte d'une autre personne ou entité
                    («vous»). En visualisant, en accédant, en postant sur, en interagissant ou en communiquant
                    avec, en effectuant des transactions de
                    toute nature sur ou via (y compris mais sans s'y limiter de faire des réservations), et / ou
                    de toute autre manière utilisant ce site, et / ou Room Mobile App (ci-après
                    «Application», comme indiqué ci-dessous) (les activités
                    précédentes sont collectivement désignées par les termes «Utilisation» ou «Utilisation»),
                    http://wwRoom.com/privacy . En utilisant l'Application, en plus des conditions
                    susmentionnées, vous acceptez les conditions d'utilisation
                    de l'Application définies dans le «Contrat de licence de l'application» (ci-après le
                    «CLUF»). Le CLUF est automatiquement accessible lors du téléchargement de l'application à
                    partir de n'importe quel magasin d'applications
                    en ligne (tel qu'iTunes) proposant cette application. (Voir, par exemple,
                    https://itunes.apple.com/us/app/Room-resorts/id980069965?mt=8 pour une description de
                    l'application). Si vous n'acceptez pas les conditions susmentionnées,
                    vous n'êtes pas autorisé à utiliser ce site ou l'application. Nous nous réservons le droit,
                    à notre seule discrétion, de modifier, d'ajouter ou de supprimer des parties des termes de
                    cet accord à tout moment et sans préavis.
                    Sauf indication contraire, ces modifications entreront en vigueur immédiatement après leur
                    publication sur http://www. hcRoom/legal . Par conséquent, veuillez vérifier
                    périodiquement http://www. hcRoom/legal pour
                    de tels changements. Vous acceptez par les présentes que votre utilisation du site après la
                    publication des modifications apportées au présent contrat à l' adresse http://www.
            Room.com/legal signifie que vous acceptez toutes
                    ces modifications. Veuillez noter que des conditions générales supplémentaires peuvent
                    s'appliquer pour effectuer des réservations et / ou des arrangements d'enregistrement et /
                    ou de départ et / ou effectuer des achats et
                    / ou d'autres transactions ou activités sur ou via ce site ou l'application. Vous acceptez
                    de vous conformer aux termes et conditions énoncés dans les présentes et à tous les termes
                    et conditions supplémentaires applicables.
                    Nous nous réservons le droit, à notre seule discrétion, de révoquer ou de refuser votre
                    accès au site et / ou à l'application, y compris, sans limitation, si vous enfreignez l'une
                    des dispositions du présent contrat ou du CLUF.
                    • ADMISSIBILITÉ Comme condition de votre utilisation du site et / ou de l'application, vous
                    devez: (i) être âgé d'au moins 18 ans; (ii) vous devez posséder l'autorité légale et la
                    capacité de créer une obligation légale contraignante,
                    y compris d'être lié par les termes du présent Contrat; et (iii) votre utilisation du site
                    et / ou de l'application ne doit pas enfreindre les lois, statuts, ordonnances, règles ou
                    règlements. Vous déclarez et garantissez par
                    la présente que vous remplissez toutes les conditions susmentionnées. Si vous ne remplissez
                    pas toutes les conditions qui précèdent, vous n'êtes pas autorisé à utiliser le site ou
                    l'application. POUR PLUS D'INFORMATIONS, ÉCRIVEZ
                    À: Département juridique des hôtels et centres de villégiature</p>


                <p style="text-align:justify"> <strong>Room 1 Avenue Montaigne 75008 Paris France •
                        RESTRICTIONS SUR L'UTILISATION DU SITE ET DU CONTENU</strong> Sauf ce qui est indiqué
                    ci-dessous en ce qui concerne les «Communications» (telles que définies ci-dessous):
                    (i) tous les droits sur les informations, données, textes, logiciels, musique,
                    photographies, images, dessins, graphiques, logos, fichiers, produits, services, Les images,
                    vidéos, messages, sons, fichiers et autres éléments
                    contenus et / ou affichés sur le site, la mise en page et la conception du site, ainsi que
                    le choix et la disposition des éléments du site sont la propriété de ou sous licence de
                    Hôtels COP (ci-après dénommé "Contenu"); et
                    (ii) vous ne pouvez pas modifier, altérer, télécharger, télécharger, poster, reproduire,
                    distribuer, publier, transmettre, copier, afficher, transférer, vendre, revendre, exécuter,
                    concéder sous licence ou sous-licence le contenu,
                    ni utiliser le contenu pour créer les œuvres dérivées sous quelque forme, de quelque manière
                    ou de quelque manière que ce soit, à des fins commerciales sans l'autorisation écrite
                    préalable de Hôtels COP, Sous réserve que vous
                    respectiez les termes du présent Contrat, nous vous accordons une licence limitée, non
                    exclusive, non transférable et non sous-licenciable permettant d'accéder au contenu et de
                    l'utiliser uniquement dans le cadre de votre utilisation
                    autorisée du site et uniquement à des fins personnelles. et à des fins non commerciales. Ce
                    site affiche ou fait référence à des marques de commerce appartenant à Hôtels COP (y
                    compris, sans toutefois s'y limiter, la marque
                    « Hôtels COP» utilisé par Hôtels COP) pour distinguer ses services et ses marchandises
                    (collectivement, les «marques»). Les marques et les propriétés propriétaires associées sont
                    protégées contre la copie et la simulation en
                    vertu des lois nationales et internationales, et vous ne pouvez pas reproduire, télécharger,
                    télécharger, copier ou utiliser les marques de quelque manière que ce soit sans
                    l'autorisation écrite expresse et préalable de Hôtels
                    COP. De nombreuses marques, notamment Hôtels COP®, Hôtels COP HOTELS AND RESORTS® - sont
                    déposées auprès du US Patent and Trademark Office et / ou d’autres offices et agences de
                    marques de commerce du monde entier. Les autres
                    marques de commerce n'appartenant pas à Hôtels COP et référencées sur ce site appartiennent
                    à leurs propriétaires respectifs. Le site peut contenir ou référencer les marques, et / ou
                    d’autres marques, marques de service, noms
                    commerciaux, brevets, éléments protégés par le droit d’auteur, secrets commerciaux,
                    technologies, produits, procédés ou autres droits de propriété (collectivement «propriété
                    intellectuelle») détenus par Hôtels COP et / ou d'autres
                    parties. Aucune licence ou droit sur une telle propriété intellectuelle ne vous est accordé
                    ou attribué et vous ne pouvez utiliser la propriété intellectuelle à quelque fin que ce soit
                    (y compris celles identifiées dans les
                    dispositions de restriction énoncées ci-dessous), sauf autorisation contraire dans les
                    présentes ou telle que permise par la loi. Outre les restrictions susmentionnées, vous
                    acceptez en outre que, dans le cadre de votre utilisation
                    du site, vous ne fassiez en aucune manière: • utiliser des dispositifs ou des mécanismes, y
                    compris, mais sans s'y limiter, des logiciels, des routines, du code malveillant ou non
                    autorisé, des moteurs, des outils, des agents,
                    des robots, des robots, des robots, des outils d'exploration de données, des virus, des
                    vers, des chevaux de Troie, des logiciels malveillants, des programmes, des bombes à
                    retardement, envoyer des bombes, des cancelbots, des
                    spams ou d’autres composants nuisibles (ci-après collectivement dénommés «Dispositifs») ou
                    avoir un comportement quelconque visant à (i) interrompre, perturber, altérer, détruire,
                    altérer, restreindre, altérer ou entraver le
                    bon fonctionnement de , l'accès au ou la fourniture de services sur le site, ou (ii) de
                    surveiller, de gratter, de télécharger ou de copier le site ou le contenu, ou tout aspect de
                    celui-ci; • nous fournir ou nous envoyer des
                    informations ou des données incluant des appareils; • adopter un comportement qui crée ou
                    est destiné à créer une responsabilité pour Hôtels COP déchiffrer, décompiler, désassembler
                    ou désosser tout logiciel utilisé en connexion
                    avec le site; violer les restrictions figurant dans les en-têtes d'exclusion de robots du
                    site ou contourner, violer ou contourner des mesures de sécurité ou d'authentification et /
                    ou d'autres mesures utilisées pour empêcher
                    ou limiter l'accès au site; envoyer toute publicité non sollicitée ou non autorisée,
                    matériel promotionnel, courrier électronique, courrier indésirable, spam, chaîne de lettres
                    ou autre forme de sollicitation; falsifier tout
                    en-tête de paquet TCP / IP ou toute partie de l'information d'en-tête dans tout message
                    envoyé par e-mail ou un groupe de discussion, ou utiliser ou envoyer d'une autre manière des
                    informations d'identification faussées, trompeuses
                    ou fausses; se faire passer pour une identité ou une fausse déclaration sur votre
                    affiliation avec une personne ou une entité; collecter ou stocker sur le site des
                    informations personnellement identifiables concernant d'autres
                    utilisateurs du site sans leur autorisation expresse; intercepter ou exproprier tout
                    système, donnée ou information du Site; un lien profond vers toute partie du site (y
                    compris, sans limitation, le chemin d'achat pour tout
                    service de réservation) pour quelque fin que ce soit sans notre autorisation écrite
                    expresse; "encadrer", "créer un miroir" ou incorporer de toute autre manière une partie du
                    site ou du contenu dans un autre site Web, application
                    mobile, produit ou service sans notre autorisation écrite préalable; utiliser des balises
                    méta ou tout autre texte ou métadonnées masqués utilisant le contenu sans notre consentement
                    écrit exprès; le chemin d’achat pour tout
                    service de réservation) à quelque fin que ce soit sans notre autorisation écrite expresse;
                    "encadrer", "créer un miroir" ou incorporer de toute autre manière une partie du site ou du
                    contenu dans un autre site Web, application
                    mobile, produit ou service sans notre autorisation écrite préalable; utiliser des balises
                    méta ou tout autre texte ou métadonnées masqués utilisant le contenu sans notre consentement
                    écrit exprès; le chemin d’achat pour tout
                    service de réservation) à quelque fin que ce soit sans notre autorisation écrite expresse;
                    "encadrer", "créer un miroir" ou incorporer de toute autre manière une partie du site ou du
                    contenu dans un autre site Web, application
                    mobile, produit ou service sans notre autorisation écrite préalable; utiliser des balises
                    méta ou tout autre texte ou métadonnées masqués utilisant le contenu sans notre consentement
                    écrit exprès; • adopter un comportement
                    qui: (i) enfreint, détourne ou viole le brevet, le droit d'auteur, la marque, le secret
                    commercial, les droits moraux ou autres droits de propriété intellectuelle, droits de
                    publicité ou de confidentialité de toute autre partie;
                    (ii) est frauduleux, faux, trompeur ou trompeur; (iii) est diffamatoire, obscène,
                    pornographique, vulgaire ou offensant; (iv) encourage la discrimination, le fanatisme, le
                    racisme, la haine, le harcèlement ou les torts causés
                    à tout individu ou groupe; (v) est violent ou menace ou encourage la violence ou des actions
                    qui menacent toute personne ou entité; (vi) promeut des activités ou des substances
                    illégales ou nuisibles; (vii) viole par ailleurs
                    ou encourage tout comportement qui violerait une loi, loi, ordonnance, règle ou règlement
                    applicable ou qui engagerait la responsabilité civile; ou (viii) viole le CLUF; ou •
                    Encouragez ou permettez à toute autre personne de
                    faire ce qui précède. Des restrictions supplémentaires sur l'utilisation de ce site sont
                    définies dans d'autres dispositions du présent contrat. • RÉSERVATIONS / LOCATIONS DANS LES
                    HÔTELS QUATRE SAISONS, LES STAGES, LES RÉSIDENCES
                    ET LES CLUBS DE RÉSIDENCE Vous ne ferez que des réservations légitimes de bonne foi que vous
                    et / ou vos invités et / ou d'autres personnes pour le compte desquelles vous êtes autorisé
                    à agir, et non à d'autres fins, y compris,
                    sans limitation, la revente, la cession ou l'affichage illicites de sites Web de tiers, ou
                    faire des réservations spéculatives, fausses ou frauduleuses, ou des réservations en
                    prévision de la demande. Nous nous réservons le
                    droit d'annuler ou de modifier les réservations à notre seule discrétion, pour quelque
                    raison que ce soit, y compris lorsqu'il apparaît qu'un client s'est livré à une activité
                    frauduleuse ou inappropriée ou dans d'autres circonstances
                    où il apparaît que les réservations contiennent ou ont résulté d'une erreur ou d'une erreur,
                    même si une telle erreur ou erreur est la nôtre. Pour contester l'annulation d'une
                    réservation ou le gel ou la fermeture d'un compte,
                    veuillez contacter notre service clientèle. • MOTS DE PASSE Notre site peut vous permettre
                    d'utiliser des noms d'utilisateur, mots de passe ou autres codes ou appareils pour accéder à
                    certaines parties de notre site («mots
                    de passe»). Vous êtes entièrement responsable du maintien de la confidentialité de vos mots
                    de passe et de toutes les activités qui se déroulent sous votre compte. Nous nous réservons
                    le droit de résilier votre compte immédiatement,
                    à notre entière discrétion et sans préavis, y compris, par exemple, si vous enfreignez une
                    partie quelconque du présent contrat ou du CLUF.
                    <p style="text-align:justify">LES COMMUNICATIONS afficher publiquement et exécuter et / ou
                        autrement utiliser ou divulguer à d'autres personnes ces communications ou les
                        incorporer sous une forme, un forum, un support ou une technologie quelconque, dans
                        le monde entier, dans tous les médias connus ou à venir, y compris sans limitation, le
                        développement, la production et la commercialisation de produits et services incorporant
                        de telles communications; (ii) utilisez le
                        nom que vous indiquez en relation avec ces communications; et / ou attribuer vos
                        communications (par exemple, en indiquant votre nom et votre ville natale sur une
                        critique d'hôtel que vous soumettez) à notre seule discrétion;
                        et (iii) poursuivre en justice toute personne ou entité qui enfreint vos droits ou nos
                        droits dans les communications en enfreignant les présentes conditions. Nous ne prenons
                        aucune responsabilité et ne sommes pas responsables
                        des communications postées sur le site ou soumises par vous. Nous n'avons aucune
                        obligation d'afficher vos communications et nous nous réservons le droit, à notre seule
                        discrétion, de décider de publier et / ou de conserver
                        des communications sur le site. Nous aurons le droit (mais non l'obligation) de
                        surveiller et d'examiner les communications transmises ou reçues via le site et de
                        censurer, éditer, supprimer ou interdire la transmission
                        ou la réception de communications (en tout ou en partie) que nous jugerons inappropriés
                        ou en violation de cet accord. Pendant la surveillance, vos communications peuvent être
                        examinées, enregistrées ou copiées par nous,
                        et votre utilisation du site constitue votre consentement à cette surveillance, cet
                        enregistrement et cette révision. Ce qui précède n'est limité que par notre engagement
                        et nos obligations concernant vos informations personnelles
                        énoncées dans la politique de confidentialité. Si vous n'acceptez pas ces conditions,
                        veuillez ne pas utiliser le site ou l'application. Sous réserve de ce qui précède, rien
                        dans le présent Contrat ne sera considéré comme
                        limitant les droits que vous pourriez avoir d’utiliser, de modifier et / ou d’exploiter
                        vos communications. Merci de ne pas nous envoyer de messages confidentiels et d'utiliser
                        le courrier électronique Internet uniquement
                        pour nous envoyer des messages non confidentiels. N'incluez pas d'informations
                        confidentielles personnelles ou privées. N'utilisez pas le courrier électronique
                        Internet pour nous envoyer des instructions de transaction
                        (y compris, par exemple, des instructions comprenant des informations sur une carte de
                        crédit, un virement bancaire, un routage, des opérations bancaires ou toute autre
                        information confidentielle). Les clients qui choisissent
                        d'envoyer à ROOM des messages électroniques contenant des informations
                        confidentielles, privées ou personnelles à ROOM le font entièrement à leurs
                        propres risques.</p>
                    <p style="text-align:justify"> <strong>CONFORMITÉ D'ACCESSIBILITÉ</strong> Nous nous
                        efforçons de fournir nos produits et services de manière accessible à tous nos clients
                        et de respecter la dignité et l'indépendance des personnes handicapées. Notre énoncé
                        de politique sur le service à la clientèle de la LAPHO est disponible à l’ adresse
                        http://wwRoom.com/legal/accessibility_policy . • SITES ET MATERIAUX DE TIERS Ce
                        site contient des liens vers des sites Web et des
                        ressources exploités par des parties autres que nous, qui peuvent fournir des biens et /
                        ou des services et dont les sites Web peuvent créer un lien vers notre site (ci-après
                        «sites de tiers»). Ces liens sont fournis uniquement
                        pour votre commodité. Nous ne contrôlons pas ces sites tiers et ne sommes pas
                        responsables de leur contenu ou de leur exactitude. Nous n'offrons aucune garantie en ce
                        qui concerne et n'assumons aucune responsabilité pour
                        eux, pour les liens affichés sur ces sites Web ou pour tout matériel, produit ou service
                        tiers que vous avez acheté, loué, loué ou acheté de toute autre manière à partir de ces
                        sites tiers. L'inclusion sur le site de liens
                        vers des sites tiers n'implique aucune approbation ni aucune exactitude du contenu de
                        ces sites ni aucune association avec leurs exploitants. • LE DROIT CHOIX DE
                        FAIRE RESERVATION AU ROOM se réserve le
                        droit d'apporter des modifications, des corrections, des annulations et / ou des
                        améliorations au site et au contenu, ainsi qu'aux produits, services et programmes
                        décrits, à tout moment et sans préavis, y compris après
                        la confirmation de la transaction. </p>
                </p>


                <p style="text-align:justify"> <strong>INDEMNISATION ET LIBERATION</strong> violation ou
                    violation de toute propriété intellectuelle ou de droits personnels (y compris, sans
                    limitation, droit d'auteur, brevet, secret commercial, marque commerciale, marque de
                    service, nom de domaine, artiste, droit moral, droits relatifs à la vie privée et / ou à la
                    publicité, ou diffamation) ou violation de tout autre droit de quelque nature que ce soit
                    (ci-après dénommé «réclamation» et collectivement,
                    «réclamations») découlant de, concerne, concerne ou concerne de quelque manière que ce soit:
                    (i) le présent Contrat (y compris, sans limitation, une violation par vous le présent Accord
                    ou le CLUF); (ii) le site, y compris,
                    mais sans s'y limiter, l'utilisation ou l'impossibilité d'utiliser ou d'accéder au site ou à
                    l'application, ou le fonctionnement ou non du site ou de l'application; (iii) le contenu;
                    (iv) sites tiers; (v) les communications;
                    (vi) les mots de passe; (vii) la propriété intellectuelle; (viii) tout acte ou omission de
                    votre part, y compris, sans limitation, toute transaction dans laquelle vous vous engagez
                    sur et / ou en relation avec le site, l'application
                    et / ou des sites tiers; et / ou (ix) l'exécution ou la non-exécution par les Parties
                    indemnisées en relation avec une transaction, ou activité sur ou liée au Site, à
                    l'Application et / ou à des Sites de tiers (ci-après, les
                    sous-sections (i) à (ix) de la présente section sont appelées «liste des revendications»).
                    se rapportant ou se rapportant de quelque manière que ce soit aux éléments énumérés dans la
                    liste des revendications. Vous avez été
                    informé de l'existence de l'article 1542 du code civil de Californie ("article 1542"), qui
                    dispose: UNE LIBÉRATION GÉNÉRALE NE S'ÉTEND PAS AUX RÉCLAMATIONS QUE LE CRÉDITEUR NE SAURAIT
                    OU NE SUSPECTE D'EXISTER À SA FAVEUR AU
                    MOMENT DE L'EXÉCUTION DE LA LIBÉRATION, SI SA CONNAÎTRE CE QU'IL EXISTE, IL DOIT AVOIR AVOIR
                    AFFIRMÉ MATÉRIELLEMENT AFFECTÉ SON RÈGLEMENT AVEC LE DÉBUT. NONOBSTANT CETTE DISPOSITION,
                    cette libération constitue une libération
                    complète conformément à ses termes. Vous renoncez sciemment et volontairement aux
                    dispositions de la section 1542, ainsi qu'à toute autre loi, loi ou règle d'effet similaire.
                    Dans le cadre de cette renonciation et de cette
                    renonciation, vous reconnaissez que vous savez que vous pouvez désormais découvrir des
                    réclamations actuellement inconnues ou insoupçonnées, ou des faits supplémentaires ou
                    différents de ceux que vous savez ou croyez être vrais,
                    en ce qui concerne: les sujets publiés ici. Néanmoins, vous avez l’intention, par le biais
                    de la présente convention et avec l’avis de l’avocat, de régler complètement et
                    définitivement toutes ces questions et toutes les réclamations
                    y relatives qui existent, peuvent exister ou ont existé entre les parties. ci-après, y
                    compris les parties indemnisées. • Votre utilisation du site et de l'application est à vos
                    risques et périls. Le site et l'application sont
                    fournis "tels quels" et sur une base "selon disponibilité" sans déclarations ni garanties de
                    quelque nature que ce soit, expresse, implicite ou légale. Dans la mesure maximale permise
                    par la loi applicable, au nom des parties
                    indemnisées, nous déclinons expressément toute garantie, expresse ou implicite, y compris,
                    mais sans s'y limiter, les garanties implicites de qualité marchande, d'adéquation à un
                    usage particulier, de titre, de non-violation.
                    , la conception, la précision, la capacité, la suffisance, la pertinence, la capacité,
                    l’exhaustivité, la disponibilité ou la compatibilité, ou résultant d’un cours ou d’une
                    performance. Nous excluons expressément, et vous
                    renoncez par la présente à toute responsabilité des parties indemnisées pour tout dommage
                    spécial, indirect, direct, accidentel, En particulier, et sans limitation, nous ne faisons
                    aucune déclaration, garantie ou endossement
                    verbal, écrit ou autre concernant l’application, le contenu ou le site (y compris, mais sans
                    s'y limiter, l’utilisation et / ou le fonctionnement du site), et déclinons toute et toutes
                    les responsabilités concernant l'application,
                    le contenu et le site (y compris, mais sans s'y limiter, l'utilisation et / ou le
                    fonctionnement du site). Si vous êtes insatisfait du site ou de tout aspect de celui-ci, ou
                    des membres ou des fournisseurs qui y sont associés,
                    selon le cas, votre seul et unique recours consiste à cesser l'utilisation du site. Notre
                    responsabilité et / ou responsabilité pour les produits et / ou services fournis sur ou via
                    le site sont limitées aux dommages résultant
                    de notre non-conformité brute ou intentionnelle.</p>


                <p style="text-align:justify"> <strong>LIMITATION DE RESPONSABILITÉ ET RENONCIATION</strong>
                    Nous ne garantissons pas la confidentialité ou la confidentialité de toute communication ou
                    information transmise sur le site ou tout site Web lié au site. Nous ne serons
                    pas responsables de la confidentialité des communications et / ou de toute autre
                    information, adresses de courrier électronique, informations d'enregistrement et
                    d'identification, espace disque, informations confidentielles
                    ou de secret commercial, ou de tout autre contenu transmis sur les réseaux auxquels le site
                    accède, ou autrement liés à votre utilisation du site. • PAS D'AGENCE Vous et nous sommes
                    des entrepreneurs indépendants et aucune
                    relation d'agence, de partenariat, de coentreprise, d'employé-employeur ou de
                    franchiseur-franchisé n'est prévue ou créée par le présent Contrat. • RÈGLEMENT DES
                    DIFFÉRENDS (PAS DE PROCÈS DEVANT JURY NI DE RECOURS COLLECTIFS,
                    ARBITRAGE, RECOURS DEVANT LE TRIBUNAL DE NEW YORK) 1. Absence de procès en jury ou de
                    recours collectif VOUS RECONNAISSEZ ET ACCEPTEZ QUE VOUS ET NOUS RENONCEONS À UN DROIT VOUS
                    OU NOUS POUVONS MAINTENANT POSSÉDER UN PROCESSUS
                    À UN PROCÈS JURY OU PARTICIPER EN TANT QUE MEMBRE DE LA CLASSE À TOUTE ACTION CLASSE OU
                    REPRÉSENTANTE COMMANDÉE OU ACTION REPRÉSENTANTE RÉGLEMENTÉE » DÉFINI CI-DESSOUS), Y COMPRIS
                    TOUT “ACTION DE PROTECTION IP” (TELLE QUE DÉFINIE
                    CI-DESSOUS) ET “AUTRE ACTION” (TELLE QUE DÉFINIE CI-DESSOUS). 2. arbitrage Général Vous et
                    nous convenons que tout litige, réclamation ou controverse découlant de ou lié à cet accord
                    ou à la violation, la résiliation, l'exécution,
                    l'interprétation ou la validité du présent ou l'utilisation du site ou concernant les
                    communications, les mots de passe ou les revendications (collectivement, "conflits" ) seront
                    réglés par arbitrage contraignant, sauf que
                    chaque partie conserve le droit: (i) d'intenter une action individuelle devant une cour des
                    petites créances, et (ii) de demander une mesure injonctive ou une autre réparation
                    équitable devant le tribunal de New York (tel que
                    défini ci-après): empêcher toute violation réelle ou potentielle, appropriation illicite ou
                    violation des droits d'auteur, marques de commerce, secrets commerciaux, brevets ou autres
                    droits de propriété intellectuelle d'une
                    partie (l'action décrite dans la clause (ii) précédente, une «action de protection de la
                    propriété intellectuelle»). Restrictions des arbitres À moins que vous et nous convenions
                    par écrit, l'arbitre ne peut pas regrouper les
                    demandes de plus d'une personne ni présider de quelque manière que ce soit des procédures
                    d'un groupe, d'un jury ou d'un représentant. Si cette section «Restrictions de l'arbitre»
                    est jugée non exécutoire, l'intégralité de
                    cette section «Arbitrage» sera considérée comme nulle et les parties seront liées par les
                    sections restantes de la présente convention relatives au règlement des différends. Sauf
                    disposition contraire dans la phrase précédente,
                    cette section «Arbitrage» survivra à toute résiliation du présent Contrat. Règlement
                    d'arbitrage L’arbitrage sera administré par l’American Arbitration Association («AAA»)
                    conformément aux Règles d’arbitrage commercial et aux
                    Procédures complémentaires pour les litiges en matière de consommation (les «Règles AAA»)
                    alors en vigueur, sauf dans la mesure modifiée par le présent «Règlement des litiges».
                    section. (Les règles de l'AAA sont disponibles
                    sur www.adr.org/arb_med ou en appelant l'AAA au 1-800-778-7879.) La loi fédérale sur
                    l'arbitrage régira l'interprétation et l'application de cette section. Processus d'arbitrage
                    Une partie qui souhaite engager un arbitrage
                    doit fournir à l'autre partie une demande écrite d'arbitrage, conformément aux règles de
                    l'AAA. (L’AAA fournit un formulaire de demande d’arbitrage à l’ adresse
                    https://www.adr.org/aaa/ShowPDF?doc=ADRSTG_015820 et un formulaire
                    distinct pour les résidents de la Californie à l’ adresse
                    https://www.adr.org/aaa/ShowPDF?doc = ADRSTG_015822 ). L'arbitre sera soit un juge à la
                    retraite, soit un avocat autorisé à pratiquer le droit, et sera choisi par les
                    parties parmi les arbitres de l'AAA. Si les parties sont incapables de s’entendre sur un
                    arbitre dans les sept (7) jours suivant la remise de la demande d’arbitrage, l’AAA le
                    nommera conformément aux Règles de l’AAA. Lieu et
                    procédure d'arbitrage À moins d’accord de votre part, l’arbitrage aura lieu dans le comté où
                    vous résidez. Si votre demande ne dépasse pas 10 000 $, alors l'arbitrage se déroulera
                    uniquement sur la base des documents que vous
                    et nous soumettons à l'arbitre, à moins que vous ne demandiez une audience ou que l'arbitre
                    ne décide qu'une audience est nécessaire. Si votre demande dépasse 10 000 $, votre droit à
                    une audience sera déterminé par les règles
                    de l'AAA. Sous réserve des règles de l'AAA, l'arbitre aura le pouvoir discrétionnaire
                    d'organiser un échange d'informations raisonnable entre les parties, conformément à la
                    nature accélérée de l'arbitrage. Décision de l'arbitre
                    L'arbitre rendra sa sentence dans les délais spécifiés dans les règles de l'AAA. La décision
                    de l'arbitre inclura les conclusions et conclusions essentielles sur lesquelles l'arbitre a
                    fondé sa décision. Le jugement sur la
                    sentence arbitrale peut être inscrit devant tout tribunal compétent. L'attribution de
                    dommages-intérêts par l'arbitre doit être conforme aux termes de la section «Clause de
                    non-responsabilité et limitation de responsabilité
                    et renonciation» ci-dessus en ce qui concerne les types et le montant des dommages et
                    intérêts pour lesquels notre responsabilité peut être engagée. L'arbitre ne peut accorder
                    une mesure de redressement déclaratoire ou injonctive
                    qu'en faveur du demandeur et uniquement dans la mesure nécessaire pour fournir une
                    réparation justifiée par la demande individuelle du demandeur. Si vous avez gain de cause en
                    arbitrage, vous aurez droit à une indemnité d’avocat
                    et aux frais d’avocat, dans la mesure prévue par la loi. Nous ne chercherons pas, Honoraires
                    Votre responsabilité de payer les frais de dépôt, d’administration et d’arbitre de l’AAA
                    sera uniquement conforme aux Règles de l’AAA.
                    Changements Nonobstant les conditions du présent contrat nous permettant de modifier les
                    termes du présent contrat, si nous modifions cette section «Résolution des litiges» après la
                    date à laquelle vous avez accepté pour la
                    première fois les termes du présent contrat (ou toute modification ultérieure des termes du
                    présent contrat), vous pouvez refuser toute modification ultérieure. changement en nous
                    envoyant un avis écrit à l’adresse indiquée
                    ci-dessous à la rubrique «Coordonnées» dans les 30 jours suivant la date à laquelle cette
                    modification est entrée en vigueur, comme indiqué dans la date «Dernière mise à jour»
                    ci-dessus ou dans la date de réception de notre
                    courrier électronique (si aucun) vous notifiant d'un tel changement. En refusant toute
                    modification, vous acceptez d'arbitrer tout litige entre vous et nous conformément aux
                    dispositions de la présente section «Résolution des
                    litiges» à la date à laquelle vous avez accepté pour la première fois les conditions du
                    présent contrat (ou toute modification ultérieure du contrat). termes de la présente).
                    Limite de temps Vous convenez que, quelles que soient
                    les lois et les lois contraires, vous devez soumettre les différends à l'arbitrage dans un
                    délai d'un (1) an après que cette réclamation ou cause d'action se soit produite ou soit
                    définitivement interdite. 3. Actions devant
                    les tribunaux de New York La juridiction exclusive et le lieu de toute action de protection
                    de la propriété intellectuelle, et de toute autre action relative aux litiges résultant si
                    la section «Restrictions de l'arbitre» ou
                    la section «Arbitrage» entière est jugée non exécutoire (ci-après dénommé «Autre action»)
                    est le district des États-Unis. Tribunal du district sud de New York ou, s’il n’ya pas de
                    compétence fédérale en la matière, devant les
                    tribunaux de l’État de New York, situés dans l’arrondissement et le comté de Manhattan, New
                    York (ci-après, collectivement, les «tribunaux de New York») ), et vous consentez par les
                    présentes à renoncer à toute défense d’absence
                    de compétence personnelle, de lieu et / ou de forum non conveniens en ce qui concerne le
                    lieu et la compétence devant les tribunaux de New York.
                </p>

                <p style="text-align:justify"><strong> VOTRE RECOURS SE LIMITE AU REMPLACEMENT DE CES PRODUITS
                        OU SERVICES. EN CE QUI CONCERNE LES PRODUITS OU SERVICES SUR LE SITE POUR LESQUELS NOUS
                        NE SOMMES PAS LES FOURNISSEURS RÉELS DE CES PRODUITS ET SERVICES,
                        NOUS DÉCLINONS TOUTE RESPONSABILITÉ QUI LUI ÉTAIT. SI VOUS AVEZ DES PROBLÈMES LIÉS À DE
                        TELS PRODUITS ET SERVICES, VOUS ACCEPTEZ QUE VOTRE RECOURS UNIQUE EST AVEC LE MARCHAND
                        OU LE FOURNISSEUR DE SERVICES QUI FOURNIT CES PRODUITS
                        ET SERVICES ET NON AVEC NOUS. LES EXCLUSIONS ET LIMITES DES DOMMAGES MENTIONNÉS
                        CI-DESSUS SONT DES ÉLÉMENTS FONDAMENTAUX DE LA BASE DE LA NÉGOCIATION ENTRE LES
                        ÉTATS-UNIS ET VOUS. CERTAINES JURIDICTIONS LIMITENT OU NE PERMETTENT
                        PAS LE DÉGAGEMENT DE GARANTIES IMPLICITES OU AUTRES, LE DÉCLARATION CI-DESSUS PEUT NE
                        PAS S'APPLIQUER DANS LA MESURE OU UNE TELLE LOI DU JURIDICTION S'APPLIQUERA À VOUS ET À
                        CES TERMES. • AVIS DE LA LOI SUR LA CONFIDENTIALITÉ DES
                        COMMUNICATIONS ÉLECTRONIQUES (18 USC 2701-2711)</strong> Vous reconnaissez et acceptez
                    en outre que toute violation de nos droits de propriété intellectuelle et / ou de cet accord
                    peut entraîner des dommages irréparables ou des
                    dommages pour nous pour lesquels nous ne disposerons pas d'un recours juridique adéquat. En
                    conséquence, en plus des autres recours et dommages dont nous disposons, vous reconnaissez
                    et acceptez que dans le cas où nous déterminons
                    raisonnablement que vous avez violé ou menacé de violer nos droits de propriété
                    intellectuelle et / ou que vous avez violé le présent Contrat et qu'une telle violation nous
                    cause ou pourrait nous causer un dommage irréparable,
                    nous aurons droit à un redressement injonctif immédiat et permanent, sans aucune obligation
                    de créer un cautionnement ou une autre garantie, et vous acceptez de ne pas contester notre
                    droit à un tel redressement. Si nous l'emportons
                    dans une action de protection de la propriété intellectuelle ou une autre action, nous
                    serons en droit de récupérer auprès de vous, et vous acceptez de payer, tous les honoraires
                    d'avocat raisonnables, le coût de ces actions,
                    ainsi que toute autre réparation à laquelle nous pourrions avoir droit. , y compris, mais
                    sans s'y limiter, les dommages pécuniaires. De plus, vous acceptez que nous puissions
                    débiter votre carte de crédit ou de débit ou vous
                    facturer de tels montants. Vous convenez que, quelles que soient les lois et les lois
                    contraires, vous devez engager une action en justice relative à une action de protection de
                    la propriété intellectuelle ou à une autre action
                    dans un délai d'un (1) an après que cette revendication ou cause d'action se soit produite
                    ou soit définitivement interdite. • DISPOSITIONS GÉNÉRALES Sauf dans la mesure où la loi en
                    vigueur dans votre pays de résidence exige
                    l'application d'une autre loi et / ou juridiction et prévoit que cette application d'une
                    autre loi et / ou juridiction ne peut faire l'objet d'une renonciation ni être modifiée par
                    contrat, le présent Contrat est régi et interprété
                    de manière interprétative. conformément aux lois de l’État de New York, sans donner effet à
                    aucun principe de conflit de lois. En tout état de cause, le présent Accord ne sera pas régi
                    par la Convention des Nations Unies sur
                    les contrats de vente internationale de marchandises. Sauf disposition contraire des
                    présentes, si un tribunal juge une disposition de la présente convention illégale, nulle ou
                    pour toute raison inexécutoire, cette disposition
                    sera réputée dissociable de la présente convention et n’affectera en rien la validité et le
                    caractère exécutoire des dispositions restantes. des provisions. Le présent contrat, la
                    politique de confidentialité et le CLUF constituent
                    l'intégralité de l'accord entre nous concernant le contenu de la présente publication et ne
                    peuvent être modifiés, sauf indication contraire. Vous pouvez également être soumis à des
                    termes et conditions supplémentaires pouvant
                    s'appliquer lorsque vous achetez des biens et des services auprès de fournisseurs tiers.
                    Aucun manquement ou retard de notre part dans l’exercice d’un droit ou d’un recours en vertu
                    des présentes ou dans l’application des conditions
                    générales du présent Contrat ne pourra être considéré comme une renonciation. Sauf
                    stipulation expresse dans les présentes, aucune renonciation à quelque terme, disposition ou
                    condition du présent Contrat, que ce soit par sa
                    conduite ou autrement, dans un ou plusieurs cas, ne sera réputée être, ou constituer, une
                    renonciation à tout autre terme. disposition ou condition des présentes, qu’elle soit ou non
                    similaire, aucune renonciation ne constitue
                    une renonciation permanente à une telle condition, disposition ou condition. Aucune
                    renonciation ne sera contraignante à moins d’être signée par écrit par un représentant
                    autorisé de la partie qui fait la renonciation. Sauf
                    disposition expresse contraire dans le présent Contrat, l’exercice par l’une des parties de
                    tout recours en vertu des termes du présent Contrat ne préjugera en rien des autres recours
                    disponibles aux termes des présentes ou
                    autrement disponibles. Vous acceptez de signer et de nous livrer, sous forme enregistrable
                    si nécessaire, d'autres documents, instruments ou accords, et prendre toute autre mesure
                    nécessaire ou appropriée pour atteindre les
                    objectifs du présent Accord. Toute notification ou autre communication fournie par nous en
                    vertu du présent Contrat, y compris celles concernant des modifications du Contrat, sera
                    transmise: (i) par courrier électronique; ou
                    (ii) en postant sur le site ou l'application. Pour les avis envoyés par courrier
                    électronique, la date de réception sera considérée comme la date à laquelle cet avis est
                    transmis. INFORMATIONS DE CONTACT Si vous avez des questions
                    sur le présent contrat ou le CLUF, veuillez nous contacter au service juridique de Room and Resorts 1165, rue Leslie Toronto, Ontario Canada M3C 2K8 AVIS ET PROCÉDURE À
                    SUIVRE POUR</p>

                <p style="text-align:justify"> <strong>RÉCLAMER UNE VIOLATION DE DROIT D'AUTEUR EN VERTU DE LA
                        LOI SUR LE DROIT D'AUTEUR
                        DU DIGITAL MILLENNIUM </strong>("DMCA") Room a enregistré un agent auprès du
                    Bureau du droit d'auteur des États-Unis conformément aux dispositions de la loi américaine
                    sur le droit d'auteur du millénaire, 17 USC § 512 (la
                    "Loi"), et se prévaut des protections prévues par cette loi. Nous nous réservons le droit de
                    supprimer tout contenu posté par un visiteur du site ("Contenu de l'utilisateur") qui
                    enfreindrait le droit d'auteur d'une autre personne
                    aux États-Unis. Nous ne sommes nullement tenus d'analyser le contenu publié pour rechercher
                    toute violation des droits de tiers. Toutefois, nous respectons les droits d'auteur d'autrui
                    et notre politique est de ne pas laisser
                    les éléments connus de notre part enfreindre les droits d'auteur d'une autre partie. sur le
                    site. Si vous pensez que des éléments du site portent atteinte à un droit d'auteur, vous
                    devez nous fournir un avis écrit contenant
                    au minimum: • Une signature physique ou électronique d'une personne autorisée à agir au nom
                    du titulaire d'un droit exclusif prétendument violé; • Identification de l'œuvre protégée
                    par le droit d'auteur dont il est allégué
                    qu'elle a été violée ou, si plusieurs œuvres protégées sur un même site Web sont couvertes
                    par une seule notification, une liste représentative de ces œuvres; • Identification du
                    matériel présumé contrefaisant ou faisant l'objet
                    d'une activité illicite, devant être retiré ou dont l'accès doit être désactivé, et
                    informations raisonnablement suffisantes pour nous permettre de localiser le matériel,
                    telles que l'inclusion de l'URL du matériel présumé
                    enfreindre la loi ou le sujet d'une activité illicite; • Informations raisonnablement
                    suffisantes pour nous permettre de contacter la partie plaignante, telles qu'une adresse, un
                    numéro de téléphone et, le cas échéant, une
                    adresse de courrier électronique; • Une déclaration selon laquelle la partie plaignante
                    croit de bonne foi que l'utilisation du matériel de la manière incriminée n'est pas
                    autorisée par le titulaire du droit d'auteur, son mandataire
                    ou la loi; et • Une déclaration indiquant que les informations figurant dans la notification
                    sont exactes et sous peine de parjure, que la partie plaignante est autorisée à agir pour le
                    compte du titulaire d'un droit exclusif
                    prétendument violé. Tous les avis DMCA doivent être envoyés à notre agent désigné comme
                    suit: Room Limited 1, Avenue Montaigne 75008 Paris France À l'attention de
                    l'avocat général copyright@hcopluxe.com CONTRE-AVIS.
                    Si votre contenu d'utilisateur a été supprimé du site en réponse à la réception d'une
                    notification DMCA par Room, comme indiqué ci-dessus, et que vous estimez que la
                    suppression était inappropriée, vous pouvez envoyer
                    une contre-notification DMCA en contactant notre agent désigné à l'adresse indiquée.
                    ci-dessus et fournissez à l'agent les informations suivantes: • Votre signature physique ou
                    électronique; • Identification du contenu qui
                    a été supprimé ou dont l'accès a été désactivé, ainsi que l'emplacement où le contenu est
                    apparu avant sa suppression ou son accès a été désactivé; • Une déclaration sous peine de
                    parjure selon laquelle vous croyez de bonne
                    foi que le contenu a été supprimé ou désactivé à la suite d'une erreur ou d'une
                    identification erronée du contenu à supprimer ou à désactiver; • Vos nom, adresse, numéro de
                    téléphone et, le cas échéant, votre adresse électronique;
                    et • Une déclaration indiquant que vous consentez à la compétence de la Cour de district
                    fédéral pour le district judiciaire dans lequel votre adresse est située ou, si votre
                    adresse est en dehors des États-Unis, pour tout
                    district judiciaire pour lequel la compétence Hôtels COP peut être déterminée, et que vous
                    accepterez la signification du processus de la personne qui a soumis la notification DMCA ou
                    d'un mandataire de cette personne. Droits
                    d'auteur © 1997-2015 Room Limited. Tous droits réservés. Sauf indication
                    contraire dans les présentes, si un tribunal juge une disposition illégale, nulle ou pour
                    toute raison inexécutable, cette disposition sera
                    réputée dissociable du présent Accord et n'affectera pas la validité et l'applicabilité des
                    dispositions restantes.
                </p>
            </P>
        </div>
    </div>
</div>
</div>


<?php

require_once('inc/footer.php'); 