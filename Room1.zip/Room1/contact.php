
<?php

require_once('include/init.php');
$title = 'Contact'; // titre de la page



require_once('include/header.php');




?>



    <!-- ----------------------------------acces------------------------ -->

    <div class="container">

        <h2>Accès</h2>
        <p style="text-align:center">Notre adresse:</p>
        <hr>
        <p style="text-align:center"> <strong>1 avenue Montaigne, 75008 Paris</strong> </p>
        <div class="row" style="margin-bottom:10px">
            <div class="col-md-4 text-center">
                <div class="card">
                    <img alt="" src="img/003-underground.png" style="width: 64px; height: 64px;margin:5px auto"
                        class="card-img-top">
                    <div class="card-body">
                        <p class="card-title"><span style="letter-spacing:1px; text-align: center"><span
                                    style="color:#000000;">METRO</span></span></p>
                        <p class="card-text"><span style="color:#ae9b66;">Alma-Marceau </span></p>
                        <p><span style="color:#ae9b66;">3 min à pieds</span></p>
                    </div>
                </div>
            </div>




            <div class="col-md-4 text-center">

                <div class="card">
                    <img alt="" src="img/004-bus.png" style="width: 64px; height: 64px;margin:5px auto "
                        class="card-img-top">
                    <div class="card-body">
                        <p class="card-title"><span style="letter-spacing:1px;text-align: center"><span
                                    style="color:#000000;">BUS</span></span></p>
                        <p class="card-text"><span style="color:#ae9b66;">Alma-Marceau </span></p>
                        <p><span style="color:#ae9b66;">2 min à pieds</span></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 text-center">

                <div class="card">
                    <img alt="" src="img/002-electric-car.png" style="width: 64px; height: 64px;margin:5px auto"
                        class="card-img-top">
                    <div class="card-body">
                        <p class="card-title"><span style="letter-spacing:1px;"><span
                                    style="color:#000000;">VOITURE</span></span></p>
                        <p class="card-text"><span style="color:#ae9b66;">Periph puis suivre Paris Centre</span></p>
                        <p><span style="color:#ae9b66;">10 min Porte Maillot</span></p>
                    </div>
                </div>
            </div>

        </div>
        <div class="row" style="margin-bottom:10px">
            <div class="col-md-12 text-center">
                <div class="carte" style="margin:auto"> <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d20997.199182189215!2d2.2842744264858594!3d48.86488612442522!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fdd0b743c25%3A0xf7293b466460cc38!2s1.+Avenue+Montaigne%2C+75008+Paris!5e0!3m2!1sfr!2sfr!4v1556626654434!5m2!1sfr!2sfr"
                        width="100%" height="450px" frameborder="0"
                        style="border:0;margin-right:auto;margin-left:auto;display:block" allowfullscreen></iframe>
                </div>
            </div>
        </div>

    </div>



    <!-- ----------------------------------------contact------------------------------------ -->

    <div class="container">
        <h2 style="margin:30px 0">Contact</h2>
        <form>
            <div class="form-group">
                <label for="exampleFormControlInput1">Prenom</label>
                <input type="surname" class="form-control" id="exampleFormControlInput1" placeholder="Votre prenom">
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Nom</label>
                <input type="name" class="form-control" id="exampleFormControlInput1" placeholder="Votre nom">
            </div>

            <div class="form-group">
                <label for="exampleFormControlInput1">Email addresse</label>
                <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="nom@exemple.com">
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Entreprise</label>
                <input type="name" class="form-control" id="exampleFormControlInput1" placeholder="Votre entreprise">
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Pays</label>
                <input type="name" class="form-control" id="exampleFormControlInput1" placeholder="Votre pays">
            </div>

            <div class="form-group">
                <label for="exampleFormControlInput1">Sujet</label>
                <input type="name" class="form-control" id="exampleFormControlInput1">
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Categorie</label>
                <select class="form-control" id="exampleFormControlSelect1">
                    <option>Chambre</option>
                    <option>Restaurant</option>
                    <option>Spa</option>
                    <option>Ordre generale</option>

                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1">Votre Message</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
        </form>
        <a href=""><button type="button " class="btn btn-warning " style=" margin-right: auto;
                            margin-left: auto; display: block;margin-bottom:20px">Envoyez</button></a>


    </div>





    <?php
require_once('include/footer.php'); 
?>

