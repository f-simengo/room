<?php
require_once('include/init.php');


$title = 'Accueil'; // titre de la page


require_once('include/header.php');






require_once('include/footer.php');
?>